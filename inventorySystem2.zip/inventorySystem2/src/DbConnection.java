/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author mgado
 */
import java.sql.*;


public class DbConnection {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/inventory_system";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    
    private Connection connection;
    private Statement statement;
    
    public void open() throws SQLException {
        connection = DriverManager.getConnection(DB_URL, USER, PASSWORD);
        statement = connection.createStatement();
    }
    
    public void close() throws SQLException {
        statement.close();
        connection.close();
    }
    
    public boolean execute(String sql) throws SQLException {
        return statement.execute(sql);
    }
    
    public ResultSet query(String sql) throws SQLException {
        return statement.executeQuery(sql);
    }
    
}
